ISS Live Wallpaper – Android projekt

Ovaj projekt je početna verzija žive pozadine:
- animirano zvjezdano nebo
- stilizirana Zemlja s plavom atmosferom i svjetlima
- ISS ilustriran detaljnim elementima koji se polako pomiče
- ciljano umjereno osvježavanje radi potrošnje baterije

VAŽNO:
Ovo je izvorni Android projekt, ne već kompajliran APK. U ovom okruženju nije dostupna Android/Gradle toolchain konfiguracija za pouzdano izgraditi i testirati APK.

Kako izgraditi APK:
1. Otvoriti projekt u Android Studio.
2. Pričekati da se Gradle sinkronizira.
3. Izabrati Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK će biti u app/build/outputs/apk/debug/app-debug.apk.
5. Na mobitelu otvoriti APK i dopustiti instalaciju iz tog izvora ako Android to zatraži.
6. Nakon instalacije: Postavke > Pozadina > Žive pozadine (nazivi se razlikuju po mobitelu) > ISS – Realistični svemir.

Napomena: ISS i Zemlja su stilizirana animacija, ne stvarni 3D model niti praćenje stvarnog položaja ISS-a.
