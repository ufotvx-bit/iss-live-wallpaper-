package com.example.isslive;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.os.Handler;
import android.os.Looper;
import java.util.Random;

public class ISSWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new SpaceEngine(); }

    private class SpaceEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random(41);
        private final float[] sx = new float[150], sy = new float[150], ss = new float[150];
        private boolean visible = false;
        private long start = System.currentTimeMillis();
        private final Runnable drawTask = new Runnable() { @Override public void run() { drawFrame(); } };

        SpaceEngine() {
            for (int i=0;i<sx.length;i++) { sx[i]=random.nextFloat(); sy[i]=random.nextFloat(); ss[i]=0.5f+random.nextFloat()*1.8f; }
        }
        @Override public void onVisibilityChanged(boolean v) {
            visible=v; if (v) drawFrame(); else handler.removeCallbacks(drawTask);
        }
        @Override public void onSurfaceChanged(SurfaceHolder h,int f,int w,int he) { super.onSurfaceChanged(h,f,w,he); drawFrame(); }
        @Override public void onSurfaceDestroyed(SurfaceHolder h) { visible=false; handler.removeCallbacks(drawTask); super.onSurfaceDestroyed(h); }
        @Override public void onDestroy() { visible=false; handler.removeCallbacks(drawTask); super.onDestroy(); }

        private void drawFrame() {
            SurfaceHolder holder=getSurfaceHolder();
            Canvas c=null;
            try {
                c=holder.lockCanvas();
                if (c!=null) render(c);
            } catch(Exception ignored) { }
            finally { if(c!=null) holder.unlockCanvasAndPost(c); }
            handler.removeCallbacks(drawTask);
            if(visible) handler.postDelayed(drawTask, 40); // about 25 fps to reduce battery use
        }

        private void render(Canvas c) {
            int w=c.getWidth(), h=c.getHeight();
            float t=(System.currentTimeMillis()-start)/1000f;
            c.drawColor(Color.rgb(2,5,18));
            // Deep-space nebula haze
            p.setShader(new RadialGradient(w*.18f,h*.18f,w*.65f,
                new int[]{0x33235B9A,0x11112A5C,0x00000000},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            // Stars drift gently
            for(int i=0;i<sx.length;i++) {
                float x=(sx[i]*w + (float)Math.sin(t*.05f+i)*5 + w)%w;
                float y=(sy[i]*h + (float)Math.cos(t*.04f+i)*3 + h)%h;
                int alpha=130+(int)(100*(.5+.5*Math.sin(t*1.4+i)));
                p.setColor(Color.argb(alpha,220,232,255)); c.drawCircle(x,y,ss[i],p);
            }
            // Earth limb, slowly rotating underneath the station
            float cx=w*.50f + (float)Math.sin(t*.12f)*w*.025f;
            float cy=h*.90f;
            float r=Math.max(w*.78f,h*.60f);
            p.setShader(new RadialGradient(cx-w*.17f,cy-r*.53f,r*1.75f,
                new int[]{0xff4f9bd2,0xff123e78,0xff06142e,0xff01040c},
                new float[]{0f,.48f,.79f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r,p); p.setShader(null);
            // Atmospheric blue rim
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(5,w*.012f));
            p.setColor(0x8844bfff); c.drawArc(cx-r,cy-r,cx+r,cy+r,195,150,false,p); p.setStyle(Paint.Style.FILL);
            // Soft cloud bands and shifting continents
            c.save(); c.clipRect(0,h*.48f,w,h);
            for(int i=0;i<9;i++) {
                float yy=cy-r*.60f+i*r*.18f;
                p.setColor(i%2==0?0x20ffffff:0x1300bfff);
                c.drawOval(cx-r*.95f,yy,cx+r*.95f,yy+r*.065f,p);
            }
            p.setColor(0x5537a86e);
            for(int i=0;i<7;i++) {
                float xx=cx+(float)Math.sin(t*.16+i*1.7)*r*.55f;
                float yy=cy-r*.36f+i*r*.16f;
                c.drawOval(xx-r*.20f,yy-r*.07f,xx+r*.17f,yy+r*.08f,p);
            }
            // city lights
            for(int i=0;i<75;i++) {
                float xx=cx+(float)Math.sin(i*12.31+t*.02)*r*.78f;
                float yy=cy-r*.20f+(i%13)*r*.045f;
                p.setColor(0x99ffc66b); c.drawCircle(xx,yy,1.2f+(i%3)*.5f,p);
            }
            c.restore();
            // Sun glow from upper left
            p.setShader(new RadialGradient(w*.05f,h*.12f,w*.48f,
                new int[]{0x66fff1c2,0x22ffd58a,0x00000000},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            // ISS slowly translates and gently rocks
            c.save();
            c.translate(w*.51f+(float)Math.sin(t*.18f)*w*.035f, h*.43f+(float)Math.sin(t*.25f)*h*.018f);
            c.rotate((float)Math.sin(t*.15f)*2.4f);
            float s=Math.min(w/420f,h/780f)*1.25f;
            c.scale(s,s);
            drawISS(c);
            c.restore();
        }

        private void drawISS(Canvas c) {
            // Main truss
            p.setColor(0xffb9c6d2); c.drawRoundRect(-145,-5,145,5,3,3,p);
            p.setColor(0xff778b9b); c.drawRect(-125,-2,125,2,p);
            // solar arrays, grid cells
            for(int side=-1;side<=1;side+=2) for(int j=0;j<2;j++) {
                float x=side*(70+j*57);
                p.setColor(0xff172d4b); c.drawRect(x-21,-70,x+21,70,p);
                p.setColor(0xffb77b35); p.setStrokeWidth(1.1f); p.setStyle(Paint.Style.STROKE);
                c.drawRect(x-21,-70,x+21,70,p);
                for(int k=1;k<8;k++) c.drawLine(x-21,-70+k*17.5f,x+21,-70+k*17.5f,p);
                c.drawLine(x,-70,x,70,p); p.setStyle(Paint.Style.FILL);
            }
            // modules and connecting tubes
            p.setColor(0xffe0e5e8);
            c.drawRoundRect(-48,-12,48,12,7,7,p);
            c.drawRoundRect(-23,-24,22,24,8,8,p);
            p.setColor(0xffaab7c1);
            c.drawRoundRect(-12,-32,12,32,6,6,p);
            p.setColor(0xfff3f5f6);
            c.drawCircle(0,0,10,p);
            p.setColor(0xff536b7e);
            c.drawCircle(0,0,5,p);
            // antenna booms
            p.setColor(0xffd4dce1); p.setStrokeWidth(2);
            c.drawLine(-28,-13,-55,-34,p); c.drawLine(28,-13,56,-34,p);
            c.drawLine(-55,-34,-67,-34,p); c.drawLine(56,-34,69,-34,p);
            c.drawCircle(-68,-34,3,p); c.drawCircle(70,-34,3,p);
            // highlights
            p.setColor(0x88ffffff);
            c.drawLine(-40,-8,38,-8,p); c.drawLine(-8,-27,-8,25,p);
        }
    }
}
